package com.mg.filesearch;

//@SpringBootTest
class FilesearchApplicationTests {

	/*
	 * @Test void contextLoads() { }
	 */

}
